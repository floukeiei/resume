module.exports = {
  projects: ['<rootDir>/apps/resume'],
};
