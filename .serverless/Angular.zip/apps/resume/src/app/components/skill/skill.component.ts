import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'resume-skill',
  templateUrl: './skill.component.html',
  styleUrls: ['./skill.component.scss']
})
export class SkillComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
