import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'resume-outside',
  templateUrl: './outside.component.html',
  styleUrls: ['./outside.component.scss']
})
export class OutsideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
